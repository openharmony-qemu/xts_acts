/**
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hilog/log.h"
#include "napi/native_api.h"
#include <chrono>
#include <string>
#include "common/native_common.h"
#include "web/native_interface_arkweb.h"
#include "web/arkweb_interface.h"
#include "jsbridge_object.h"
#include <thread>


constexpr unsigned int LOG_PRINT_DOMAIN = 0xFF00;
ArkWeb_ControllerAPI *controller = nullptr;
ArkWeb_JavaScriptValueAPI *javaScriptValueApi = nullptr;
std::shared_ptr<JSBridgeObject> jsbridge_object_ptr = nullptr;

std::chrono::time_point<std::chrono::high_resolution_clock> start;

int funcOnePid = -1;
int funcTwoPid = -1;

std::thread::id this_id = std::this_thread::get_id();
std::size_t hash_value_cur = std::hash<std::thread::id>()(this_id);
int m_pid = static_cast<int>(hash_value_cur);

char *GetStringValue(napi_env env, napi_value value) {
    size_t size = 0;
    napi_get_value_string_utf8(env, value, nullptr, 0, &size);
    char *paramValue = new (std::nothrow) char[size + 1];
    size_t paramLength = 0;
    napi_get_value_string_utf8(env, value, paramValue, size + 1, &paramLength);
    return paramValue;
}

// 发送JS脚本到H5侧执行，执行结果的回调
static void RunJavaScriptCallback(const char *result)
{
    std::chrono::duration<double, std::milli> elapsed_ms = std::chrono::high_resolution_clock::now() - start;
}

// 示例代码 ，注册了1个对象，2个方法
static char *ProxyMethod1(const char **argv, int argc)
{
    return nullptr;
}

static char *ProxyMethod2(const char **argv, int argc)
{
    char *ret = "ygz hello from native ProxyMethod2";
    return ret;
}

static char *ProxyMethod3(const char **argv, int argc)
{
    char *ret = "ygz hello from native ProxyMethod3";
    return ret;
}

void ValidCallback(const char *webName)
{
    const char *methodName[2] = {"method1", "method2"};
    NativeArkWeb_OnJavaScriptProxyCallback callback[2] = {ProxyMethod1, ProxyMethod2};
    // 如此注册的情况下，在H5页面就可以使用proxy.method1、proxy.method1调用此文件下的ProxyMethod1和ProxyMethod2方法了
    int32_t size = 2;
    OH_NativeArkWeb_RegisterJavaScriptProxy(webName, "ndkProxy", methodName, callback, size, false);
}

void DestroyCallback(const char *webName)
{
}

static napi_value NativeWebInit(napi_env env, napi_callback_info info)
{
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    // 获取第一个参数 webName
    size_t webNameSize = 0;
    napi_get_value_string_utf8(env, args[0], nullptr, 0, &webNameSize);
    char *webNameValue = new (std::nothrow) char[webNameSize + 1];
    size_t webNameLength = 0;
    napi_get_value_string_utf8(env, args[0], webNameValue, webNameSize + 1, &webNameLength);

    // 注js proxy册回调函数
    NativeArkWeb_OnValidCallback ptr = ValidCallback;
    OH_NativeArkWeb_SetJavaScriptProxyValidCallback(webNameValue, ptr);
    OH_NativeArkWeb_GetJavaScriptProxyValidCallback(webNameValue);
    // 注册destroy回调函数
    OH_NativeArkWeb_SetDestroyCallback(webNameValue, DestroyCallback);
    OH_NativeArkWeb_GetDestroyCallback(webNameValue);
    napi_value output;
    NAPI_CALL(env, napi_create_string_utf8(env, "RunSuccess", NAPI_AUTO_LENGTH, &output));
    return output;
}

// 发送JS脚本到H5侧执行
static napi_value RunJavaScript(napi_env env, napi_callback_info info)
{
    size_t argc = 2;
    napi_value args[2] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);

    // 获取第一个参数 webName
    size_t webNameSize = 0;
    napi_get_value_string_utf8(env, args[0], nullptr, 0, &webNameSize);
    char *webNameValue = new (std::nothrow) char[webNameSize + 1];
    size_t webNameLength = 0;
    napi_get_value_string_utf8(env, args[0], webNameValue, webNameSize + 1, &webNameLength);

    // 获取第二个参数 jsCode
    size_t bufferSize = 0;
    napi_get_value_string_utf8(env, args[1], nullptr, 0, &bufferSize);
    char *jsCode = new (std::nothrow) char[bufferSize + 1];
    size_t byteLength = 0;
    napi_get_value_string_utf8(env, args[1], jsCode, bufferSize + 1, &byteLength);
    start = std::chrono::high_resolution_clock::now();

    // 调用ndk接口
    OH_NativeArkWeb_RunJavaScript(webNameValue, jsCode, RunJavaScriptCallback);
    napi_value output;
    NAPI_CALL(env, napi_create_string_utf8(env, "RunSuccess", NAPI_AUTO_LENGTH, &output));
    return output;
}

static napi_value RegisterJavaScriptProxy(napi_env env, napi_callback_info info)
{
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    // 获取第一个参数 webName
    size_t webNameSize = 0;
    napi_get_value_string_utf8(env, args[0], nullptr, 0, &webNameSize);
    char *webNameValue = new (std::nothrow) char[webNameSize + 1];
    size_t webNameLength = 0;
    napi_get_value_string_utf8(env, args[0], webNameValue, webNameSize + 1, &webNameLength);
    const char *methodName[3] = {"method1", "method2", "method3"};
    NativeArkWeb_OnJavaScriptProxyCallback callback[3] = {ProxyMethod1, ProxyMethod2, ProxyMethod3};
    // 如此注册的情况下，在H5页面就可以使用proxy.method1、proxy.method1调用此文件下的ProxyMethod1和ProxyMethod2方法了
    int32_t size = 3;
    OH_NativeArkWeb_RegisterJavaScriptProxy(webNameValue, "ndkProxy", methodName, callback, size, false);
    napi_value output;
    NAPI_CALL(env, napi_create_string_utf8(env, "RunSuccess", NAPI_AUTO_LENGTH, &output));
    return output;
}

static napi_value UnregisterJavaScriptProxy(napi_env env, napi_callback_info info)
{
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    // 获取第一个参数 webName
    size_t webNameSize = 0;
    napi_get_value_string_utf8(env, args[0], nullptr, 0, &webNameSize);
    char *webNameValue = new (std::nothrow) char[webNameSize + 1];
    size_t webNameLength = 0;
    napi_get_value_string_utf8(env, args[0], webNameValue, webNameSize + 1, &webNameLength);
    NativeArkWeb_OnJavaScriptProxyCallback callback[3] = {ProxyMethod1, ProxyMethod2, ProxyMethod3};
    // 如此注册的情况下，在H5页面就可以使用proxy.method1、proxy.method1调用此文件下的ProxyMethod1和ProxyMethod2方法了
    OH_NativeArkWeb_UnregisterJavaScriptProxy(webNameValue, "ndkProxy");
    napi_value output;
    NAPI_CALL(env, napi_create_string_utf8(env, "RunSuccess", NAPI_AUTO_LENGTH, &output));
    return output;
}

ArkWeb_JavaScriptValuePtr ArkWebProxyMethodOne(const char *webTag, const ArkWeb_JavaScriptBridgeData *dataArray, size_t arraySize, void *userData) {
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ArkWebProxyMethodOne webTag:%{public}s userData:%{public}s", webTag, (char *)userData);
    std::size_t hash_value = std::hash<std::thread::id>()(std::this_thread::get_id());
    funcOnePid = static_cast<int>(hash_value);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ArkWebProxyMethodOne PID:%{public}d, Fid:%{public}d", m_pid, funcOnePid);
    jsbridge_object_ptr->ProxyMethod(dataArray, arraySize);
    std::string str = std::string((char *)userData);
    return javaScriptValueApi->createJavaScriptValue(ArkWeb_JavaScriptValueType::ARKWEB_JAVASCRIPT_STRING, (void *)str.c_str(), str.length() + 1);
}

ArkWeb_JavaScriptValuePtr ArkWebProxyMethodTwo(const char *webTag, const ArkWeb_JavaScriptBridgeData *dataArray, size_t arraySize, void *userData) {
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ArkWebProxyMethodTwo webTag:%{public}s userData:%{public}s", webTag, (char *)userData);
    std::size_t hash_value = std::hash<std::thread::id>()(std::this_thread::get_id());
    funcTwoPid = static_cast<int>(hash_value);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ArkWebProxyMethodTwo PID:%{public}d, Fid:%{public}d", m_pid, funcTwoPid);
    jsbridge_object_ptr->ProxyMethod(dataArray, arraySize);
    bool boolValue = true;
    return javaScriptValueApi->createJavaScriptValue(ArkWeb_JavaScriptValueType::ARKWEB_JAVASCRIPT_BOOL, (void *)(&boolValue), 1);
}

ArkWeb_JavaScriptValuePtr ArkWebProxyMethodThree(const char *webTag, const ArkWeb_JavaScriptBridgeData *dataArray, size_t arraySize, void *userData) {
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ArkWebProxyMethodThree webTag:%{public}s userData:%{public}s", webTag, (char *)userData);
    jsbridge_object_ptr->ProxyMethod(dataArray, arraySize);
    return javaScriptValueApi->createJavaScriptValue(ArkWeb_JavaScriptValueType::ARKWEB_JAVASCRIPT_NONE, (void *)nullptr, 1);
}

ArkWeb_ProxyObjectWithResult GetProxyObjectWithResult(napi_env env, napi_value args[]){
    ArkWeb_ProxyMethodWithResult *methodList = new ArkWeb_ProxyMethodWithResult[3];
    const char *userDataOne = "method1";
    const char *userDataTwo = "method2";
    const char *userDataThree = "method3";
    methodList[0] = {"method1", ArkWebProxyMethodOne, (void *)userDataOne};
    methodList[1] = {"method2", ArkWebProxyMethodTwo, (void *)userDataTwo};
    methodList[2] = {"method3", ArkWebProxyMethodThree, (void *)userDataThree};

    int32_t size = 3;
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "AsyncRegister", "methodSize:%{public}d", size);
    ArkWeb_ProxyObjectWithResult proxyObject = {"ndkProxy", methodList, (size_t)size};
    return proxyObject;
}



static napi_value NativeWebInitTwo(napi_env env, napi_callback_info info) {
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ndk NativeWebInitTwo start");
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    // 获取第一个参数 webName
    size_t webTagSize = 0;
    napi_get_value_string_utf8(env, args[0], nullptr, 0, &webTagSize);
    char *webTagValue = new (std::nothrow) char[webTagSize + 1];
    size_t webTagLength = 0;
    napi_get_value_string_utf8(env, args[0], webTagValue, webTagSize + 1, &webTagLength);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ndk NativeWebInitTwo webTag:%{public}s", webTagValue);

    jsbridge_object_ptr = std::make_shared<JSBridgeObject>(webTagValue);
    if (jsbridge_object_ptr) {
        jsbridge_object_ptr->Init();
    }

    controller = reinterpret_cast<ArkWeb_ControllerAPI *>(OH_ArkWeb_GetNativeAPI(ARKWEB_NATIVE_CONTROLLER));
    javaScriptValueApi = reinterpret_cast<ArkWeb_JavaScriptValueAPI *>(OH_ArkWeb_GetNativeAPI(ARKWEB_NATIVE_JAVASCRIPT_VALUE));
    if (javaScriptValueApi) {
        OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "get ArkWeb_JavaScriptValueAPI success");
    }

    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "ndk NativeWebInitTwo end");

    napi_value output;
    NAPI_CALL(env, napi_create_string_utf8(env, "RunSuccess", NAPI_AUTO_LENGTH, &output));
    return output;
}

static napi_value RegisterAsyncThreadJavaScriptProxy(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value args[2] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);

    char *webTagValue = GetStringValue(env, args[0]);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "AsyncRegister", "ndk RegisterAsyncThreadJavaScriptProxy webTag:%{public}s", webTagValue);

    char *permission = GetStringValue(env, args[1]);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "AsyncRegister", "ndk RegisterAsyncThreadJavaScriptProxy permission:%{public}s", permission);

    if (strcmp(permission, "null") == 0) {
        permission = nullptr;
    }
    if (strcmp(webTagValue, "null") == 0) {
        webTagValue = nullptr;
    }

    ArkWeb_ProxyObjectWithResult proxyObjectWithResult = GetProxyObjectWithResult(env, args);
    //OH_NativeArkWeb_RegisterAsyncThreadJavaScriptProxy(webTagValue, &proxyObjectWithResult, permission);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "AsyncRegister", "OH_NativeArkWeb_RegisterAsyncThreadJavaScriptProxy success");

    controller->refresh(webTagValue);
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "AsyncRegister", "ArkWeb_ControllerAPI refresh");

    napi_value output;
    NAPI_CALL(env, napi_create_string_utf8(env, "RunSuccess", NAPI_AUTO_LENGTH, &output));
    return output;

}

static napi_value GetPidResult(napi_env env, napi_callback_info info) {
    napi_value result;
    OH_LOG_Print(LOG_APP, LOG_INFO, LOG_PRINT_DOMAIN, "ArkWeb", "GetPidResult m_pid:%{public}d, funcOnePid:%{public}d, funcTwoPid:%{public}d", m_pid, funcOnePid, funcTwoPid);
    int32_t testResult = 0;
    if (m_pid != funcOnePid && m_pid != funcTwoPid && funcOnePid == funcTwoPid) {
        testResult = 1;
    }
    napi_create_int32(env, testResult, &result);
    return result;
}



EXTERN_C_START
static napi_value Init(napi_env env, napi_value exports)
{
    napi_property_descriptor desc[] = {
        {"nativeWebInit", nullptr, NativeWebInit, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runJavaScript", nullptr, RunJavaScript, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"registerJavaScriptProxy", nullptr, RegisterJavaScriptProxy, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"unregisterJavaScriptProxy", nullptr, UnregisterJavaScriptProxy, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"nativeWebInitTwo", nullptr, NativeWebInitTwo, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"registerAsyncThreadJavaScriptProxy", nullptr, RegisterAsyncThreadJavaScriptProxy, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"getPidResult", nullptr, GetPidResult, nullptr, nullptr, nullptr, napi_default, nullptr},
    };
    napi_define_properties(env, exports, sizeof(desc) / sizeof(desc[0]), desc);
    return exports;
}
EXTERN_C_END

static napi_module demoModule = {
    .nm_version = 1,
    .nm_flags = 0,
    .nm_filename = nullptr,
    .nm_register_func = Init,
    .nm_modname = "entry",
    .nm_priv = ((void *)0),
    .reserved = {0},
};

extern "C" __attribute__((constructor)) void RegisterEntryModule(void)
{
    napi_module_register(&demoModule);
}