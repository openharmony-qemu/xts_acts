/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export const add: (a: number, b: number) => number;
export const nativeWebInit: (webName: string) => string;
export const runJavaScript: (webName: string, jsCode: string) => string;
export const registerJavaScriptProxy: (webName: string) => string;
export const unregisterJavaScriptProxy: (webName: string) => string;
export const nativeWebInitTwo: (webTag: string) => string;
export const registerAsyncThreadJavaScriptProxy: (webTag: string, permission: string) => string;
export const getPidResult: () => number;